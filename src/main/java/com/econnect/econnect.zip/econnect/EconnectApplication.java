package com.econnect.econnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EconnectApplication {

    public static void main(String[] args) {
        SpringApplication.run(EconnectApplication.class, args);
    }

}
